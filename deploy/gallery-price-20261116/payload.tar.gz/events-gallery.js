(()=>{
 const root=document.querySelector('[data-events-carousel]');if(!root)return;
 const track=root.querySelector('.events-track'),slides=[...track.children];
 const prev=root.querySelector('[data-event-prev]'),next=root.querySelector('[data-event-next]'),pause=root.querySelector('[data-event-pause]'),count=root.querySelector('[data-event-count]');
 const reduce=matchMedia('(prefers-reduced-motion: reduce)');
 let paused=false,visible=false,dragging=false,timer=null,frame=0;
 const index=()=>Math.min(slides.length-1,Math.round(track.scrollLeft/(slides[1].offsetLeft-slides[0].offsetLeft)));
 const atEnd=()=>track.scrollLeft>=track.scrollWidth-track.clientWidth-3;
 function paint(){const i=index();count.textContent=String(i+1).padStart(2,'0')+' / '+String(slides.length).padStart(2,'0');prev.disabled=track.scrollLeft<3;next.disabled=atEnd();pause.textContent=paused?'Включить показ':'Пауза';pause.setAttribute('aria-pressed',String(paused));}
 function schedule(){clearTimeout(timer);if(paused||!visible||dragging||document.hidden||document.querySelector("#lightbox[open]"))return;timer=setTimeout(()=>{move(atEnd()?0:index()+1);schedule()},3000);}
 function restart(){schedule()}
 function move(i){track.scrollTo({left:slides[Math.max(0,Math.min(i,slides.length-1))].offsetLeft-slides[0].offsetLeft,behavior:reduce.matches?'instant':'smooth'});}
 prev.addEventListener('click',()=>{restart();move(index()-1)});
 next.addEventListener('click',()=>{restart();move(index()+1)});
 pause.addEventListener('click',()=>{paused=!paused;paint();schedule()});
 track.addEventListener('pointerdown',()=>{dragging=true;schedule()},{passive:true});
 window.addEventListener('pointerup',()=>{dragging=false;schedule()},{passive:true});
 window.addEventListener('pointercancel',()=>{dragging=false;schedule()},{passive:true});
 document.querySelector('#lightbox')?.addEventListener('close',schedule);
 track.addEventListener('keydown',e=>{if(!['ArrowLeft','ArrowRight','Home','End'].includes(e.key))return;e.preventDefault();restart();move(e.key==='Home'?0:e.key==='End'?slides.length-1:index()+(e.key==='ArrowRight'?1:-1))});
 track.addEventListener('scroll',()=>{cancelAnimationFrame(frame);frame=requestAnimationFrame(paint)},{passive:true});
 document.addEventListener('visibilitychange',schedule);
 reduce.addEventListener('change',()=>{paint();schedule()});
 new IntersectionObserver(entries=>{visible=entries[0].isIntersecting;schedule()},{threshold:.3}).observe(track);
 new ResizeObserver(paint).observe(track);paint();
})();
