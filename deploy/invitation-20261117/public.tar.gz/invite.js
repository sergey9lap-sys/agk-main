(() => {
 'use strict';
 document.documentElement.classList.add('js');
 const reduce=matchMedia('(prefers-reduced-motion: reduce)');
 const dialog=document.querySelector('#opening'),main=document.querySelector('#main'),hero=document.querySelector('.hero');
 let timer,opening=false,playId=0,filmUrl=null;const film=document.querySelector('#opening-film');let mediaPromise;function loadFilm(){return mediaPromise||(mediaPromise=fetch('assets/opening.webp?v=6').then(r=>{if(!r.ok)throw Error('animation unavailable');return r.blob()}).catch(e=>{mediaPromise=null;throw e}))};const key='mf-invitation-opened-2026';
 function seen(){try{return localStorage.getItem(key)==='yes'}catch{return false}}
 function remember(){try{localStorage.setItem(key,'yes')}catch{}}
 function finish(animate=false){playId++;clearTimeout(timer);if(filmUrl){URL.revokeObjectURL(filmUrl);filmUrl=null}film.onload=null;film.src='assets/opening-poster.webp';opening=false;dialog.classList.remove('opening-now');dialog.close();document.body.style.overflow='';main.inert=false;remember();if(animate&&!reduce.matches){hero.classList.add('entered');const rain=document.createElement('div');rain.className='coin-rain';rain.setAttribute('aria-hidden','true');for(let i=0;i<12;i++){const c=document.createElement('img');c.src='assets/coin.webp';c.alt='';c.style.left=(5+i*8)+'%';c.style.animationDelay=(i%4)*.08+'s';rain.append(c)}document.body.append(rain);setTimeout(()=>rain.remove(),2400)}document.querySelector('h1').focus({preventScroll:true});}
 function show(){loadFilm().catch(()=>{});film.src='assets/opening-poster.webp';document.querySelector('#opening-title').nextElementSibling.textContent='Нажмите, чтобы открыть';hero.classList.remove('entered');window.scrollTo({top:0,behavior:'instant'});dialog.showModal();main.inert=true;document.body.style.overflow='hidden';dialog.setAttribute('tabindex','-1');dialog.focus();}
 document.querySelector('#open-envelope').addEventListener('click',async()=>{
  if(opening){finish();return}if(reduce.matches){finish();return}
  opening=true;const id=++playId;const hint=document.querySelector('#opening-title').nextElementSibling;hint.textContent='Подготавливаем приглашение…';
  timer=setTimeout(()=>{if(id===playId)finish()},8000);
  try{const blob=await loadFilm();if(id!==playId)return;filmUrl=URL.createObjectURL(blob);film.onload=()=>{if(id!==playId)return;clearTimeout(timer);hint.textContent='Ваше приглашение открывается';timer=setTimeout(()=>finish(true),1500)};film.onerror=()=>{if(id===playId)finish()};film.src=filmUrl;}catch{if(id===playId)finish()}
 });
 document.querySelector('#skip-opening').addEventListener('click',()=>finish());dialog.addEventListener('cancel',e=>{e.preventDefault();finish()});
 document.querySelectorAll('[data-replay]').forEach(b=>b.addEventListener('click',show));
 reduce.addEventListener('change',()=>{if(reduce.matches&&dialog.open)finish();document.querySelectorAll('.pending').forEach(e=>e.classList.remove('pending'))});
 if((!seen()||new URLSearchParams(location.search).has('replay'))&&!reduce.matches)show();
 const start=Date.parse('2026-12-19T10:00:00+03:00');
 function countdown(){const left=start-Date.now();const s=document.querySelector('#countdown');if(left<=0){s.hidden=true;return}document.querySelector('.clock').hidden=false;const minutes=Math.floor(left/60000);document.querySelector('#days').textContent=String(Math.floor(minutes/1440)).padStart(2,'0');document.querySelector('#hours').textContent=String(Math.floor(minutes/60)%24).padStart(2,'0');document.querySelector('#minutes').textContent=String(minutes%60).padStart(2,'0');}
 countdown();setInterval(countdown,30000);document.addEventListener('visibilitychange',countdown);
 if(!reduce.matches&&'IntersectionObserver' in window){const obs=new IntersectionObserver(entries=>entries.forEach(e=>{if(e.isIntersecting){e.target.classList.remove('pending');obs.unobserve(e.target)}}),{threshold:.08});document.querySelectorAll('.reveal').forEach(el=>{if(el.getBoundingClientRect().top>innerHeight){el.classList.add('pending');obs.observe(el)}});document.addEventListener('focusin',e=>e.target.closest('.pending')?.classList.remove('pending'));}
 document.querySelectorAll('[data-slide]').forEach(btn=>btn.addEventListener('click',()=>{const strip=document.querySelector('.outfits');strip.scrollBy({left:parseInt(btn.dataset.slide)*(strip.querySelector('img').clientWidth+14),behavior:reduce.matches?'instant':'smooth'})}));
 // Join short prepositions, dates and the author's double surname without binding long sentences.
 const walker=document.createTreeWalker(main,NodeFilter.SHOW_TEXT);const nodes=[];while(walker.nextNode())nodes.push(walker.currentNode);nodes.forEach(n=>{n.textContent=n.textContent.replace(/(^|[\s(«])([ВвКкСсУуОоИиАа]|[Нн]а|[Пп]о|[Дд]о|[Ии]з|[Зз]а|[Оо]т|[Нн]е|[Нн]о) /g,'$1$2\u00a0').replace(/19 декабря/g,'19\u00a0декабря').replace(/Александры Горевой[‑-]Куртышевой/g,'Александры\u00a0Горевой‑Куртышевой')});
})();
